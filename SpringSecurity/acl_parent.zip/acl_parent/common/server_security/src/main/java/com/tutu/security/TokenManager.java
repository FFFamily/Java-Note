package com.tutu.security;

import io.jsonwebtoken.CompressionCodecs;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 对token进行管理
 */
@Component
public class TokenManager {
    //token有效时长
    private long tokenEcpiration = 24*60*60*1000;
    //编码秘钥
    private String tokenSignKey = "123456";
    //使用jwt根据用户名生成token
    public String createToken(String username) {
        // Jwts 是 jwt提供的工具
        String token = Jwts.builder().setSubject(username)
                // 设置时长（失效时间）
                .setExpiration(new Date(System.currentTimeMillis()+tokenEcpiration))
                // 加密操作
                .signWith(SignatureAlgorithm.HS512, tokenSignKey).compressWith(CompressionCodecs.GZIP).compact();
        return token;
    }
    //2 根据token字符串得到用户信息
    public String getUserInfoFromToken(String token) {
        String userinfo = Jwts.parser().setSigningKey(tokenSignKey).parseClaimsJws(token).getBody().getSubject();
        return userinfo;
    }
    /**
     * 删除token
     * token的删除一般在客户端就进行了
     */
    public void removeToken(String token) { }
}
